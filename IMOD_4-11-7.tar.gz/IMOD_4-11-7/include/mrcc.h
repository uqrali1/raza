/*
 *  mrcc.h -- Main mrc library header.
 */

#ifndef MRCC_H
#define MRCC_H

#include "mrcfiles.h"
#include "mrcslice.h"

#endif
