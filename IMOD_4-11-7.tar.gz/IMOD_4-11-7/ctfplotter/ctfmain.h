/* declaration for global routines */
#ifndef CTFMAIN_H
#define CTFMAIN_H

int ctfShowHelpPage( const char *);

#endif
