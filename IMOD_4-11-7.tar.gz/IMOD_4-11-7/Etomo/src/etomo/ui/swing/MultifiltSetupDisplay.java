package etomo.ui.swing;

import etomo.comscript.MultifiltSetupParam;

public interface MultifiltSetupDisplay {
  public boolean getParameters(MultifiltSetupParam param, boolean doValidation);
}
