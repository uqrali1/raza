package etomo.process;

public final class AxisBusyException extends Exception {
  public AxisBusyException(String message) {
    super(message);
  }
}
